<?php 
 require_once '../app/bootstrap.php';
 //Init Core Libaray
 $init = new Core;