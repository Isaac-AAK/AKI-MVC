<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '123456');
define('DB_NAME', 'tmvc');

// app Root

 define('APPROOT',dirname(dirname(__FILE__)));
 //URl ROOT
 define('URLROOT', 'http://localhost/isaacmvc');
 //Site Name
 define('SITENAME', 'isaacMVC');